import logo from './logo.svg';
import './App.css';
import Title from './components/title';
import Layout from './components/sidebar';
import Shit from './components/main';

function App() {
  return (
    <div className="App">
      <Title/>
      <Layout/>
      <Shit/>
    </div>
  );
}

export default App;
