import React from 'react';

function Shit() {
    return(
        <nav class="bg-dark navbar-dark navbar">
            <div className="row col-12 d-flex justify-content-center text-white">
                <h3>:(</h3>
            </div>
        </nav>
    )
}

export default Shit;
