import React from 'react';

function Title() {
    return(
        <nav class="bg-dark navbar-dark navbar">
            <div className="row col-12 d-flex justify-content-center text-white">
                <h3>My App Page</h3>
            </div>
        </nav>
    )
}

export default Title;
